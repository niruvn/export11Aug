.. _porting_guides:

**********************
Ansible Porting Guides
**********************

Ansible Porting Guides are maintained in the ``devel`` branch only. Please go to `the devel Ansible Porting guides <https://docs.ansible.com/ansible/devel/porting_guides/porting_guides.html>`_ for up to date information.
